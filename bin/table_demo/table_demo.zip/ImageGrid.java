package jlist;

import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ImageGrid {
	JFrame frame;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ImageGrid main = new ImageGrid();
		main.run();
	}
	void run() {
		frame = new JFrame();
		ImageIcon grassIcon = new ImageIcon("images/f12.png"); 
		JPanel panel = new JPanel(new GridLayout(3,4,5,5));
	
		JLabel labels[] = new JLabel[(3*4)];
		
		for (int i =  0; i < 3*4; i++)
		{
		      labels[i] = new JLabel(grassIcon );
		      labels[i].setText(""+i);
		      labels[i].setHorizontalTextPosition(JLabel.CENTER);
		      labels[i].setVerticalTextPosition(JLabel.BOTTOM);
		      labels[i].addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					JLabel label = (JLabel)e.getSource();
					JOptionPane.showMessageDialog(frame, "Click: " + label.getText());
				}
		      });
		      panel.add(labels[i]);
		}
	
		frame.add(panel);
		frame.pack();
		frame.setVisible(true);
	}
}
