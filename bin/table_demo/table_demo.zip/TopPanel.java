package table_demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class TopPanel extends JPanel {
	// Item �˻� ���� ��� �г� �����ϱ�
    void setupTopPane(TableSelectionDemo tableDemo) {
    	JPanel topPane = new JPanel();
    	topPane.setBackground(Color.GRAY);//����
        JButton detail = new JButton("�󼼺���");
        detail.setBackground(new Color(255,255,255));
        topPane.add(detail, BorderLayout.LINE_START);
        JTextField kwdTextField = new JTextField("", 20);
        topPane.add(kwdTextField, BorderLayout.CENTER);
        JButton search = new JButton("�˻�");
        search.setBackground(new Color(255,255,255));
        topPane.add(search, BorderLayout.LINE_END);
        JButton order = new JButton("�ֹ��ϱ�");
        order.setBackground(new Color(255,255,255));
        topPane.add(order, BorderLayout.SOUTH);
        add(topPane, BorderLayout.PAGE_START);
        
        detail.setBorderPainted(false); //�׵θ�       
        //detail.setContentAreaFilled(false); //������ �Ķ���
        detail.setFocusPainted(false); //������ �簢��
        search.setBorderPainted(false); //�׵θ�
        //search.setContentAreaFilled(false); //������ �Ķ���
        search.setFocusPainted(false); //������ �簢��
        order.setBorderPainted(false); //�׵θ�
        //order.setContentAreaFilled(false); //������ �Ķ���
        order.setFocusPainted(false); //������ �簢��

        detail.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if (e.getActionCommand().equals("�󼼺���")) {
        			tableDemo.showDetail();
            	}
           }
        });
        search.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if (e.getActionCommand().equals("�˻�")) {
        			tableDemo.loadData(kwdTextField.getText());
            	}
           }
        });
        order.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               if (e.getActionCommand().equals("�ֹ��ϱ�")) {
                  tableDemo.callOption();
                }
            }
         });
        
    }
}
