package table_demo;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;

import facade.DataEngineInterface;
import store.Item;

public class TableEvent extends JPanel implements MouseListener{
	TableSelectionDemo table;
	JTable jTable;
	//table�� �޾Ƽ� ������ó�� �غ���
	public TableEvent(TableSelectionDemo tableDemo) {
		this.table=tableDemo;
		jTable=tableDemo.table;
	}
	
	/*public void addEvent() {        
        jTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
	    		// TODO Auto-generated method stub
				if(selectedIndex<0)
		    		return;
		    	String[] rowTexts = new String[jTable.getColumnCount()];
		        for (int i = 0; i < rowTexts.length; i++)
		        	rowTexts[i] = (String)jTable.getValueAt(selectedIndex, i);
		        List<?> result = dataMgr.search(rowTexts[0]); //code�� ã��
		        Object od=result.get(0);
		        Item item=(Item)od; // item���� ������ ���� ������ ������ ������
		        JPanel imageTable=new JPanel(); 
		        //static���� �����ؼ� �ٿ��ֱ�? 
		        ImageIcon menu=new ImageIcon(item.itemName+".jpg");
				JLabel image=new JLabel(menu);
		    	imageTable.add(image, BorderLayout.CENTER);
			}
	      });
	}*/
	public void addEvent() {
		jTable.addMouseListener(this);
	}
	public void mouseClicked(MouseEvent e) {
	      // TODO Auto-generated method stub
	         table.getImage();
	   }
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
