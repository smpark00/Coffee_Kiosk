package table_demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;

import store.AdeMgr;
import store.CoffeeMgr;
import store.JuiceMgr;
import store.OrderMgr;
import store.OrderedItemMgr;
import store.QuickMgr;
import store.SmoothieMgr;
import store.Store;

public class GUIMain {
	static Store store = Store.getInstance();

	public static void main(String args[]) {
		store.run();
		startGUI();
	}

	public static void startGUI() {
		// Schedule a job for the event-dispatching thread:
		// creating and showing this application's GUI.
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}

	/**
	 * Create the GUI and show it. For thread safety, this method should be invoked
	 * from the event-dispatching thread.
	 */
	static JFrame mainFrame = new JFrame("CAFE UNIVERSE");

	private static void createAndShowGUI() {
		mainFrame.setBounds(100, 100, 900, 600);
		// Create and set up the window.
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JTabbedPane jtab = new JTabbedPane();
		// ��
		jtab.setBackground(Color.gray);
		jtab.setForeground(Color.white);
		setupItemPane("COFFEE");
		jtab.add("COFFEE", coffeePane);
		setupItemPane("ADE");
		jtab.add("ADE", adePane);
		setupItemPane("TEA");
		jtab.add("TEA", teaPane);
		setupItemPane("JUICE");
		jtab.add("JUICE", juicePane);
		setupItemPane("SMOOTHIE");
		jtab.add("SMOOTHIE", smoothiePane);
		setupItemPane("QUICKMENU");
		jtab.add("QUICKMENU", quickPane);
		setupOrderPane();
		jtab.add("��ٱ���", orderPane);
		jtab.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				photoPane.removeAll();
			}
		});
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Image img = toolkit.getImage("Cosat.png");
		mainFrame.setIconImage(img);
		mainFrame.getContentPane().add(jtab);
		// Display the window.
		mainFrame.pack();
		mainFrame.setVisible(true);
		mainFrame.setBounds(100, 100, 1200, 900);
		mainFrame.setLocationRelativeTo(null);// �߾ӿ��� ������
		mainFrame.setResizable(false);// ũ�� ���� �Ұ�
	}

	// private static JPanel backgroundPane=new JPanel(new BorderLayout());
	private static Container backgroundPane = mainFrame.getContentPane();

	// static JPanel photoPane=new JPanel(new GridLayout(1,1,5,5));
	static JPanel photoPane = new JPanel(new BorderLayout());
	private static JPanel coffeePane;
	private static JPanel juicePane;
	private static JPanel smoothiePane;
	private static JPanel adePane;
	private static JPanel teaPane;
	private static JPanel teaPane2;
	private static JPanel quickPane;

	private static void setupItemPane(String type) {
		// Create and set up the content pane.
		TableSelectionDemo itemTable = new TableSelectionDemo();
		photoPane.setBackground(Color.DARK_GRAY); // ��
		// itemTable.addComponentsToPane(ItemMgr.getInstance()); // �̱���
		if (type.contentEquals("COFFEE")) {
			coffeePane = new JPanel(new BorderLayout());
			coffeePane.setPreferredSize(new Dimension(1200, 50));
			itemTable.addComponentsToPane(CoffeeMgr.getInstance());
			TopPanel itemTop = new TopPanel(); // �˻��� �󼼺��� ��ư�� ���� �г�
			itemTop.setBackground(Color.GRAY); // ��
			itemTop.setupTopPane(itemTable);
			coffeePane.add(itemTop, BorderLayout.NORTH);
			coffeePane.add(itemTable, BorderLayout.CENTER);
			backgroundPane.add(coffeePane, BorderLayout.CENTER);
			TableEvent tableEvent = new TableEvent(itemTable);
			tableEvent.addEvent();
			backgroundPane.add(photoPane, BorderLayout.SOUTH);
		} else if (type.contentEquals("ADE")) {
			adePane = new JPanel(new BorderLayout());
			itemTable.addComponentsToPane(AdeMgr.getInstance());
			TopPanel itemTop = new TopPanel(); // �˻��� �󼼺��� ��ư�� ���� �г�
			itemTop.setupTopPane(itemTable);
			itemTop.setBackground(Color.GRAY);
			adePane.add(itemTop, BorderLayout.NORTH);
			adePane.add(itemTable, BorderLayout.CENTER);
			backgroundPane.add(adePane, BorderLayout.CENTER);
			TableEvent tableEvent = new TableEvent(itemTable);
			tableEvent.addEvent();
			backgroundPane.add(photoPane, BorderLayout.SOUTH);
		} else if (type.contentEquals("TEA")) {
			teaPane2 = new JPanel(new GridLayout(2,2,20,20));
			//teaPane2 = new JPanel(new FlowLayout());
			// teaPane2.setPreferredSize(new Dimension(100,100));
			teaPane = new JPanel(new BorderLayout());
			// itemTable.addComponentsToPane(TeaMgr.getInstance());
			TopPanel itemTop = new TopPanel(); // �˻��� �󼼺��� ��ư�� ���� �г�
			itemTop.setupTopPane(itemTable);
			itemTop.setBackground(Color.GRAY);
			teaPane.add(itemTop, BorderLayout.NORTH);
			teaPane2.setBackground(Color.white);
			teaPane.add(teaPane2, BorderLayout.CENTER);
			// teaPane.add(itemTable, BorderLayout.CENTER);
			backgroundPane.add(teaPane, BorderLayout.CENTER);
			// TableEvent tableEvent = new TableEvent(itemTable);
			// tableEvent.addEvent();
			// backgroundPane.add(photoPane, BorderLayout.SOUTH);
			ImageIcon i = new ImageIcon("MENU/�����ƿ��̵�.jpg");
			ImageIcon s = new ImageIcon("���̵��2.png");

			Image image2 = s.getImage();
			Image i4 = image2.getScaledInstance(70, 800, java.awt.Image.SCALE_SMOOTH);
			ImageIcon i5 = new ImageIcon(i4); // Image�� ImageIcon ����

			JLabel side = new JLabel(i5);
			teaPane.add(side, BorderLayout.WEST);

			Image image = i.getImage();
			Image i2 = image.getScaledInstance(300, 300, java.awt.Image.SCALE_SMOOTH);
			ImageIcon i3 = new ImageIcon(i2); // Image�� ImageIcon ����

			JButton b = new JButton(i3);
			b.setBackground(Color.white);;
			b.setBorderPainted(false); //�׵θ�
			b.setContentAreaFilled(false); //������ �Ķ���
			b.setFocusPainted(false); //������ �簢��
			//b.setPreferredSize(new Dimension(300, 300));
			JButton b2 = new JButton(i3);
			b2.setBackground(Color.white);
			//b2.setPreferredSize(new Dimension(300, 300));
			JButton b3 = new JButton(i3);
			b3.setBackground(Color.white);
			//b3.setPreferredSize(new Dimension(300, 300));
			JButton b4 = new JButton(i3);
			b4.setBackground(Color.white);
			//b4.setPreferredSize(new Dimension(300, 300));
			JButton b5 = new JButton(i3);
			b5.setBackground(Color.white);
			//b5.setPreferredSize(new Dimension(300, 300));
			JButton b6 = new JButton(i3);
			b6.setBackground(Color.white);
			//b6.setPreferredSize(new Dimension(300, 300));
			JButton b7 = new JButton(i3);
			b7.setBackground(Color.white);
			//b7.setPreferredSize(new Dimension(300, 300));
			JButton b8 = new JButton(i3);
			b8.setBackground(Color.white);
			//b8.setPreferredSize(new Dimension(300, 300));

			JLabel l = new JLabel(
					"<html><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>��׷���Ƽ</html>",
					SwingConstants.CENTER);
			JLabel l2 = new JLabel(
					"<html><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>��׷���Ƽ1</html>",
					SwingConstants.CENTER);
			JLabel l3 = new JLabel(
					"<html><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>��׷���Ƽ2</html>",
					SwingConstants.CENTER);
			JLabel l4 = new JLabel(
					"<html><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>��׷���Ƽ3</html>",
					SwingConstants.CENTER);
			JLabel l5 = new JLabel(
					"<html><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>��׷���Ƽ4</html>",
					SwingConstants.CENTER);
			JLabel l6 = new JLabel(
					"<html><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>��׷���Ƽ5</html>",
					SwingConstants.CENTER);
			JLabel l7 = new JLabel(
					"<html><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>��׷���Ƽ6</html>",
					SwingConstants.CENTER);
			JLabel l8 = new JLabel(
					"<html><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>��׷���Ƽ7</html>",
					SwingConstants.CENTER);

			b.add(l);
			b2.add(l2);
			b3.add(l3);
			b4.add(l4);
			b5.add(l5);
			b6.add(l6);
			b7.add(l7);
			b8.add(l8);

			teaPane2.add(b);
			teaPane2.add(b2);
			teaPane2.add(b3);
			teaPane2.add(b4);
			teaPane2.add(b5);
			teaPane2.add(b6);
			teaPane2.add(b7);
			teaPane2.add(b8);
		} else if (type.contentEquals("JUICE")) {
			juicePane = new JPanel(new BorderLayout());
			itemTable.addComponentsToPane(JuiceMgr.getInstance());
			TopPanel itemTop = new TopPanel(); // �˻��� �󼼺��� ��ư�� ���� �г�
			itemTop.setupTopPane(itemTable);
			itemTop.setBackground(Color.GRAY);
			juicePane.add(itemTop, BorderLayout.NORTH);
			juicePane.add(itemTable, BorderLayout.CENTER);
			backgroundPane.add(juicePane, BorderLayout.CENTER);
			TableEvent tableEvent = new TableEvent(itemTable);
			tableEvent.addEvent();
			backgroundPane.add(photoPane, BorderLayout.SOUTH);
		} else if (type.contentEquals("SMOOTHIE")) {
			smoothiePane = new JPanel(new BorderLayout());
			itemTable.addComponentsToPane(SmoothieMgr.getInstance());
			TopPanel itemTop = new TopPanel(); // �˻��� �󼼺��� ��ư�� ���� �г�
			itemTop.setupTopPane(itemTable);
			itemTop.setBackground(Color.GRAY);
			smoothiePane.add(itemTop, BorderLayout.NORTH);
			smoothiePane.add(itemTable, BorderLayout.CENTER);
			backgroundPane.add(smoothiePane, BorderLayout.CENTER);
			TableEvent tableEvent = new TableEvent(itemTable);
			tableEvent.addEvent();
			backgroundPane.add(photoPane, BorderLayout.SOUTH);
		} else if (type.contentEquals("QUICKMENU")) {
			quickPane = new JPanel(new BorderLayout());
			itemTable.addComponentsToPane(QuickMgr.getInstance());
			TopPanel itemTop = new TopPanel(); // �˻��� �󼼺��� ��ư�� ���� �г�
			itemTop.setupTopPane(itemTable);
			itemTop.setBackground(Color.GRAY);
			quickPane.add(itemTop, BorderLayout.NORTH);
			quickPane.add(itemTable, BorderLayout.CENTER);
			backgroundPane.add(quickPane, BorderLayout.CENTER);
			TableEvent tableEvent = new TableEvent(itemTable);
			tableEvent.addEvent();
			backgroundPane.add(photoPane, BorderLayout.SOUTH);
		}
	}

	static JPanel orderPane;
	static JPanel center = new JPanel(new BorderLayout());
	static DefaultTableModel basketModel;
	static JTable basketTable;
	static DefaultTableModel orderModel;
	static JTable orderTable;
	static JLabel price;
	static JPanel timePane = new JPanel(new FlowLayout());
	static JPanel pricePane = new JPanel(new FlowLayout());

	@SuppressWarnings("serial")
	private static void setupOrderPane() {
		basketModel = new DefaultTableModel(OrderedItemMgr.getInstance().getColumnNames(), 0) {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		basketTable = new JTable(basketModel);
		// static JScrollPane scroll = new JScrollPane(basketTable);
		orderModel = new DefaultTableModel(OrderMgr.getInstance().getColumnNames(), 0) {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		orderModel.setRowCount(0);
		// basketModel.addColumn(OrderedItemMgr.getInstance().getColumnNames(), s);
		orderTable = new JTable(orderModel);
		orderPane = new JPanel(new BorderLayout());
		basketTable.setFillsViewportHeight(false);
		basketTable.setBackground(Color.GRAY); // ��
		basketTable.setForeground(Color.white); // ��
		orderPane.setBackground(Color.GRAY); // ��
		basketTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		orderTable.setFillsViewportHeight(false);
		orderTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		orderTable.setBackground(Color.GRAY); // ��
		// JPanel timePane = new JPanel();
		// timePane.setBackground(Color.GRAY); // ��
		String time = store.timeToString();
		// JPanel timePane = new JPanel(new FlowLayout());
		timePane.add(new JLabel(time));
		timePane.setForeground(Color.white); // ��
		timePane.setBackground(Color.GRAY); // ��
		JScrollPane scroll1 = new JScrollPane(orderTable);
		orderPane.add(timePane, BorderLayout.NORTH);
		orderPane.add(scroll1, BorderLayout.SOUTH);
		JScrollPane scroll2 = new JScrollPane(basketTable);
		Basket basket = new Basket();
		JPanel right = new JPanel(new GridLayout(3, 1));
		basket.setupbasket(basketTable, basketModel, right);
		JLabel price = new JLabel("�ݾ�: ");
		pricePane.add(price);
		center.add(scroll2);
		center.add(pricePane, BorderLayout.SOUTH);
		orderPane.add(right, BorderLayout.LINE_END);
		orderPane.add(center, BorderLayout.CENTER);
	}
}